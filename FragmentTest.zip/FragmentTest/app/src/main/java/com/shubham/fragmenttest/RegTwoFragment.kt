package com.shubham.fragmenttest

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.fragment_reg_one.view.*
import kotlinx.android.synthetic.main.fragment_reg_one.view.button_next
import kotlinx.android.synthetic.main.fragment_reg_two.view.*


class RegTwoFragment : Fragment() {

    var listener2: onFragmentListener? = null
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        var view =  inflater.inflate(R.layout.fragment_reg_two, container, false)

        init(view)

        return view
    }

    private fun init(view: View) {
        view.button_next2.setOnClickListener {
            var house = view.edit_text_country.text.toString()
            var city = view.edit_text_city.text.toString()
            var country = view.edit_text_country.text.toString()
            listener2?.onClick2(house, city, country)
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        listener2 = context as MainActivity
    }

    interface onFragmentListener{
        fun onClick2(house: String, city: String, country: String)
    }
}
