package com.shubham.fragmenttest

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.fragment_submit.*
import kotlinx.android.synthetic.main.fragment_submit.view.*


class SubmitFragment : Fragment(), RegOneFragment.onFragmentListener,RegTwoFragment.onFragmentListener {

var listener: RegOneFragment.onFragmentListener? = null
var listener2 :RegTwoFragment.onFragmentListener? = null
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        var view =  inflater.inflate(R.layout.fragment_submit, container, false)

        init(view)
        return view
    }

    private fun init(view: View) {
         view.text_view_name.text.toString()
         view.text_view_email.text.toString()
        view.text_view_mobile.text.toString()
        view.text_view_house.text.toString()
        view.text_view_city.text.toString()
        view.text_view_country.text.toString()

        listener?.onClick(name = String(),email = String(),mobile = String())
        listener2?.onClick2(house = String(),city = String(),country = String())

    }

    override fun onClick(name: String, email: String, mobile: String) {
        text_view_name.text = name
        text_view_email.text = email
        text_view_mobile.text = mobile
    }

    override fun onClick2(house: String, city: String, country: String) {
        text_view_house.text = house
        text_view_city.text = country
        text_view_country.text = country
    }


}