package com.shubham.fragmenttest

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.fragment_submit.*

class MainActivity : AppCompatActivity(), RegOneFragment.onFragmentListener,
    RegTwoFragment.onFragmentListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        init()

    }

    private fun init(){
        supportFragmentManager.beginTransaction().add(R.id.fragment_container,RegOneFragment()).commit()
    }



    override fun onClick(name: String, email: String, mobile: String) {
        text_view_mobile.text = name
        text_view_email.text = email
        text_view_mobile.text = mobile
        supportFragmentManager.beginTransaction().add(R.id.fragment_container,RegTwoFragment()).commit()

    }

    override fun onClick2(house: String, city: String, country: String) {
        text_view_house.text = house
        text_view_city.text = country
        text_view_country.text = country
        supportFragmentManager.beginTransaction().add(R.id.fragment_container,SubmitFragment()).commit()
    }
}